package com.example.materialexpressivenotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    val id: Long,
    var title: String,
    var body: String,
    var pinned: Boolean = false
)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("notes", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
            var notes by remember { mutableStateOf(loadNotes()) }
            MaterialExpressiveTheme(dark) {
                NotesApp(
                    notes = notes,
                    dark = dark,
                    onDarkChange = {
                        dark = it
                        prefs.edit().putBoolean("dark", it).apply()
                    },
                    onSave = { note ->
                        notes = if (notes.any { it.id == note.id })
                            notes.map { if (it.id == note.id) note else it }
                        else notes + note
                        saveNotes(notes)
                    },
                    onDelete = { id ->
                        notes = notes.filterNot { it.id == id }
                        saveNotes(notes)
                    }
                )
            }
        }
    }

    private fun loadNotes(): List<Note> = runCatching {
        val arr = JSONArray(prefs.getString("data", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Note(o.getLong("id"), o.getString("title"), o.getString("body"), o.optBoolean("pinned"))
        }
    }.getOrDefault(emptyList())

    private fun saveNotes(notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("title", it.title)
                put("body", it.body)
                put("pinned", it.pinned)
            })
        }
        prefs.edit().putString("data", arr.toString()).apply()
    }
}

@Composable
fun NotesApp(
    notes: List<Note>,
    dark: Boolean,
    onDarkChange: (Boolean) -> Unit,
    onSave: (Note) -> Unit,
    onDelete: (Long) -> Unit
) {
    var editing by remember { mutableStateOf<Note?>(null) }
    var creating by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var search by remember { mutableStateOf(false) }

    AnimatedContent(
        targetState = editing != null || creating,
        label = "screen"
    ) { editor ->
        if (editor) {
            val base = editing ?: Note(System.currentTimeMillis(), "", "")
            EditorScreen(
                note = base,
                onBack = { editing = null; creating = false },
                onSave = {
                    onSave(it)
                    editing = null
                    creating = false
                },
                onDelete = {
                    onDelete(it)
                    editing = null
                    creating = false
                }
            )
        } else {
            HomeScreen(
                notes = notes,
                query = query,
                search = search,
                dark = dark,
                onQuery = { query = it },
                onSearch = { search = it },
                onDark = onDarkChange,
                onNew = { creating = true },
                onOpen = { editing = it },
                onDelete = onDelete
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    notes: List<Note>,
    query: String,
    search: Boolean,
    dark: Boolean,
    onQuery: (String) -> Unit,
    onSearch: (Boolean) -> Unit,
    onDark: (Boolean) -> Unit,
    onNew: () -> Unit,
    onOpen: (Note) -> Unit,
    onDelete: (Long) -> Unit
) {
    val filtered = notes
        .filter { it.title.contains(query, true) || it.body.contains(query, true) }
        .sortedByDescending { it.pinned }

    Scaffold(
        topBar = {
            if (search) {
                TopAppBar(
                    title = {
                        TextField(
                            value = query,
                            onValueChange = onQuery,
                            placeholder = { Text("Search notes") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { onSearch(false); onQuery("") }) {
                            Icon(Icons.Default.ArrowBack, "Back")
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = {
                        Text("Notes", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    },
                    actions = {
                        IconButton(onClick = { onSearch(true) }) {
                            Icon(Icons.Default.Search, "Search")
                        }
                        IconButton(onClick = { onDark(!dark) }) {
                            Icon(
                                if (dark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                "Theme"
                            )
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onNew,
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.size(64.dp)
            ) {
                Icon(Icons.Default.Add, "New note")
            }
        }
    ) { padding ->
        if (filtered.isEmpty()) {
            Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.EditNote, null, Modifier.size(72.dp))
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (query.isEmpty()) "Nothing here yet" else "No matching notes",
                        style = MaterialTheme.typography.titleLarge
                    )
                    if (query.isEmpty()) Text("Tap + to make your first note.")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.id }) { note ->
                    NoteCard(note, onOpen, onDelete)
                }
            }
        }
    }
}

@Composable
fun NoteCard(note: Note, onOpen: (Note) -> Unit, onDelete: (Long) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen(note) },
        shape = RoundedCornerShape(28.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    note.title.ifBlank { "Untitled" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                if (note.pinned) Icon(Icons.Default.PushPin, "Pinned")
            }
            if (note.body.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    note.body,
                    maxLines = 4,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = { onDelete(note.id) }) {
                    Icon(Icons.Default.DeleteOutline, "Delete")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    note: Note,
    onBack: () -> Unit,
    onSave: (Note) -> Unit,
    onDelete: (Long) -> Unit
) {
    var title by remember { mutableStateOf(note.title) }
    var body by remember { mutableStateOf(note.body) }
    var pinned by remember { mutableStateOf(note.pinned) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Edit note") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { pinned = !pinned }) {
                        Icon(
                            if (pinned) Icons.Default.PushPin else Icons.Default.PushPin,
                            "Pin"
                        )
                    }
                    TextButton(onClick = {
                        onSave(note.copy(title = title, body = body, pinned = pinned))
                    }) { Text("Save") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)
        ) {
            TextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("Title") },
                textStyle = MaterialTheme.typography.headlineMedium,
                singleLine = false,
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
            HorizontalDivider()
            TextField(
                value = body,
                onValueChange = { body = it },
                placeholder = { Text("Start writing…") },
                colors = TextFieldDefaults.colors(
                    unfocusedContainerColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxSize(),
                minLines = 12
            )
        }
    }
}

@Composable
fun MaterialExpressiveTheme(dark: Boolean, content: @Composable () -> Unit) {
    val light = lightColorScheme(
        primary = Color(0xFF6750A4),
        secondary = Color(0xFF625B71),
        tertiary = Color(0xFF7D5260)
    )
    val darkScheme = darkColorScheme(
        primary = Color(0xFFD0BCFF),
        secondary = Color(0xFFCCC2DC),
        tertiary = Color(0xFFEFB8C8)
    )
    MaterialTheme(
        colorScheme = if (dark) darkScheme else light,
        typography = Typography(),
        content = content
    )
}
