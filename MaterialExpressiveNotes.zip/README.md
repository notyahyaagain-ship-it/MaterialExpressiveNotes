# Material Expressive Notes

A tiny, local-first Android notes app built with Jetpack Compose and Material 3.

## Features
- Create/edit/delete notes
- Pin notes
- Search
- Light/dark theme toggle
- Local persistence using SharedPreferences
- Rounded expressive cards and FAB
- No account, network permission, or backend

## Build
Open the project in Android Studio and let Gradle sync. Then run the `app` configuration or use:

    ./gradlew assembleDebug

The APK will be at:

    app/build/outputs/apk/debug/app-debug.apk
